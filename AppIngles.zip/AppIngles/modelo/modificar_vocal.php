<?php
include "../modelo/conexion.php";

if (isset($_GET["id_vocal"])) {
    $id_vocal = $_GET["id_vocal"];

    $stmt = $conexion->prepare("SELECT * FROM vocals WHERE id_vocal = :id_vocal");
    $stmt->bindParam(':id_vocal', $id_vocal, PDO::PARAM_INT);
    $stmt->execute();
    $vocal = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$vocal) {
        exit('vocal no encontrado');
    }
} else {
    exit('ID de vocal no proporcionado');
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar vocal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/971fd9b73b.js" crossorigin="anonymous"></script>
</head>

<body>
    <form class="col-4 p-3 m-auto" method="POST" enctype="multipart/form-data"> 
        <h5 class="text-center alert alert-secondary">Modificar vocal</h5>
        <input type="hidden" name="id_vocal" value="<?= htmlspecialchars($vocal['id_vocal']) ?>">
        <?php include "../controlador/modificar_vocal.php"?>
        <div class="mb-3">
            <label for="nomEsp_vocal" class="form-label">Nombre en Español</label>
            <input type="text" class="form-control" id="nomEsp_vocal" name="nomEsp_vocal" value="<?= htmlspecialchars($vocal['nomEsp_vocal']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="pronunciacion_vocal" class="form-label">Pronunciación</label>
            <input type="text" class="form-control" id="pronunciacion_vocal" name="pronunciacion_vocal" value="<?= htmlspecialchars($vocal['pronunciacion_vocal']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="img_vocal" class="form-label">Foto</label>
            <input type="file" class="form-control" id="img_vocal" name="img_vocal">
            <?php if (!empty($vocal['img_vocal'])) : ?>
                <img src="data:image/png;base64,<?= base64_encode($vocal['img_vocal']) ?>" alt="Imagen de vocal" style="width: 100px; heigth:100px;">
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="audio_vocal" class="form-label">Audio</label>
            <input type="file" class="form-control" id="audio_vocal" name="audio_vocal">
            <?php if (!empty($vocal['audio_vocal'])) : ?>
                <audio controls>
                    <source src="data:audio/mp3;base64,<?= base64_encode($vocal['audio_vocal']) ?>" type="audio/mp3">
                </audio>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary" name="btnregistrar" value="ok">Registrar</button>
    </form>
</body>

</html>