<?php
include "../modelo/conexion.php";

if (isset($_GET["id_animal"])) {
    $id_animal = $_GET["id_animal"];

    $stmt = $conexion->prepare("SELECT * FROM animales WHERE id_animal = :id_animal");
    $stmt->bindParam(':id_animal', $id_animal, PDO::PARAM_INT);
    $stmt->execute();
    $animal = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$animal) {
        exit('Animal no encontrado');
    }
} else {
    exit('ID de animal no proporcionado');
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Animal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/971fd9b73b.js" crossorigin="anonymous"></script>
</head>

<body>
    <form class="col-4 p-3 m-auto" method="POST" enctype="multipart/form-data"> 
        <h5 class="text-center alert alert-secondary">Modificar Animal</h5>
        <input type="hidden" name="id_animal" value="<?= htmlspecialchars($animal['id_animal']) ?>">
        <?php include "../controlador/modificar_animal.php"?>
        <div class="mb-3">
            <label for="nomEsp_animal" class="form-label">Nombre en Español</label>
            <input type="text" class="form-control" id="nomEsp_animal" name="nomEsp_animal" value="<?= htmlspecialchars($animal['nomEsp_animal']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="nomEng_animal" class="form-label">Nombre en Inglés</label>
            <input type="text" class="form-control" id="nomEng_animal" name="nomEng_animal" value="<?= htmlspecialchars($animal['nomEng_animal']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="pronunciacion_animal" class="form-label">Pronunciación</label>
            <input type="text" class="form-control" id="pronunciacion_animal" name="pronunciacion_animal" value="<?= htmlspecialchars($animal['pronunciacion_animal']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="img_animal" class="form-label">Foto</label>
            <input type="file" class="form-control" id="img_animal" name="img_animal">
            <?php if (!empty($animal['img_animal'])) : ?>
                <img src="data:image/png;base64,<?= base64_encode($animal['img_animal']) ?>" alt="Imagen de Animal" style="width: 100px; heigth:100px;">
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="audio_animal" class="form-label">Audio</label>
            <input type="file" class="form-control" id="audio_animal" name="audio_animal">
            <?php if (!empty($animal['audio_animal'])) : ?>
                <audio controls>
                    <source src="data:audio/mp3;base64,<?= base64_encode($animal['audio_animal']) ?>" type="audio/mp3">
                </audio>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary" name="btnregistrar" value="ok">Registrar</button>
    </form>
</body>

</html>