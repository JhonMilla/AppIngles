<?php
include "../modelo/conexion.php";

if (isset($_GET["id_fruta"])) {
    $id_fruta = $_GET["id_fruta"];

    $stmt = $conexion->prepare("SELECT * FROM frutas WHERE id_fruta = :id_fruta");
    $stmt->bindParam(':id_fruta', $id_fruta, PDO::PARAM_INT);
    $stmt->execute();
    $fruta = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$fruta) {
        exit('fruta no encontrado');
    }
} else {
    exit('ID de fruta no proporcionado');
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar fruta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/971fd9b73b.js" crossorigin="anonymous"></script>
</head>

<body>
    <form class="col-4 p-3 m-auto" method="POST" enctype="multipart/form-data"> 
        <h5 class="text-center alert alert-secondary">Modificar fruta</h5>
        <input type="hidden" name="id_fruta" value="<?= htmlspecialchars($fruta['id_fruta']) ?>">
        <?php include "../controlador/modificar_fruta.php"?>
        <div class="mb-3">
            <label for="nomEsp_fruta" class="form-label">Nombre en Español</label>
            <input type="text" class="form-control" id="nomEsp_fruta" name="nomEsp_fruta" value="<?= htmlspecialchars($fruta['nomEsp_fruta']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="nomEng_fruta" class="form-label">Nombre en Inglés</label>
            <input type="text" class="form-control" id="nomEng_fruta" name="nomEng_fruta" value="<?= htmlspecialchars($fruta['nomEng_fruta']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="pronunciacion_fruta" class="form-label">Pronunciación</label>
            <input type="text" class="form-control" id="pronunciacion_fruta" name="pronunciacion_fruta" value="<?= htmlspecialchars($fruta['pronunciacion_fruta']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="img_fruta" class="form-label">Foto</label>
            <input type="file" class="form-control" id="img_fruta" name="img_fruta">
            <?php if (!empty($fruta['img_fruta'])) : ?>
                <img src="data:image/png;base64,<?= base64_encode($fruta['img_fruta']) ?>" alt="Imagen de fruta" style="width: 100px; heigth:100px;">
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="audio_fruta" class="form-label">Audio</label>
            <input type="file" class="form-control" id="audio_fruta" name="audio_fruta">
            <?php if (!empty($fruta['audio_fruta'])) : ?>
                <audio controls>
                    <source src="data:audio/mp3;base64,<?= base64_encode($fruta['audio_fruta']) ?>" type="audio/mp3">
                </audio>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary" name="btnregistrar" value="ok">Registrar</button>
    </form>
</body>

</html>