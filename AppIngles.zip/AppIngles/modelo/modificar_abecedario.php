<?php
include "../modelo/conexion.php";

if (isset($_GET["id_abecedario"])) {
    $id_abecedario = $_GET["id_abecedario"];

    $stmt = $conexion->prepare("SELECT * FROM abecedarios WHERE id_abecedario = :id_abecedario");
    $stmt->bindParam(':id_abecedario', $id_abecedario, PDO::PARAM_INT);
    $stmt->execute();
    $abecedario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$abecedario) {
        exit('abecedario no encontrado');
    }
} else {
    exit('ID de abecedario no proporcionado');
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar abecedario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/971fd9b73b.js" crossorigin="anonymous"></script>
</head>

<body>
    <form class="col-4 p-3 m-auto" method="POST" enctype="multipart/form-data"> 
        <h5 class="text-center alert alert-secondary">Modificar abecedario</h5>
        <input type="hidden" name="id_abecedario" value="<?= htmlspecialchars($abecedario['id_abecedario']) ?>">
        <?php include "../controlador/modificar_abecedario.php"?>
        <div class="mb-3">
            <label for="nomEsp_abecedario" class="form-label">Nombre en Español</label>
            <input type="text" class="form-control" id="nomEsp_abecedario" name="nomEsp_abecedario" value="<?= htmlspecialchars($abecedario['nomEsp_abecedario']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="pronunciacion_abecedario" class="form-label">Pronunciación</label>
            <input type="text" class="form-control" id="pronunciacion_abecedario" name="pronunciacion_abecedario" value="<?= htmlspecialchars($abecedario['pronunciacion_abecedario']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="img_abecedario" class="form-label">Foto</label>
            <input type="file" class="form-control" id="img_abecedario" name="img_abecedario">
            <?php if (!empty($abecedario['img_abecedario'])) : ?>
                <img src="data:image/png;base64,<?= base64_encode($abecedario['img_abecedario']) ?>" alt="Imagen de abecedario" style="width: 100px; heigth:100px;">
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="audio_abecedario" class="form-label">Audio</label>
            <input type="file" class="form-control" id="audio_abecedario" name="audio_abecedario">
            <?php if (!empty($abecedario['audio_abecedario'])) : ?>
                <audio controls>
                    <source src="data:audio/mp3;base64,<?= base64_encode($abecedario['audio_abecedario']) ?>" type="audio/mp3">
                </audio>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary" name="btnregistrar" value="ok">Registrar</button>
    </form>
</body>

</html>