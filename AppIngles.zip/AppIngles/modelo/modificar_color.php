<?php
include "../modelo/conexion.php";

if (isset($_GET["id_color"])) {
    $id_color = $_GET["id_color"];

    $stmt = $conexion->prepare("SELECT * FROM colores WHERE id_color = :id_color");
    $stmt->bindParam(':id_color', $id_color, PDO::PARAM_INT);
    $stmt->execute();
    $color = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$color) {
        exit('color no encontrado');
    }
} else {
    exit('ID de color no proporcionado');
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar color</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/971fd9b73b.js" crossorigin="anonymous"></script>
</head>

<body>
    <form class="col-4 p-3 m-auto" method="POST" enctype="multipart/form-data"> 
        <h5 class="text-center alert alert-secondary">Modificar color</h5>
        <input type="hidden" name="id_color" value="<?= htmlspecialchars($color['id_color']) ?>">
        <?php include "../controlador/modificar_color.php"?>
        <div class="mb-3">
            <label for="nomEsp_color" class="form-label">Nombre en Español</label>
            <input type="text" class="form-control" id="nomEsp_color" name="nomEsp_color" value="<?= htmlspecialchars($color['nomEsp_color']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="nomEng_color" class="form-label">Nombre en Inglés</label>
            <input type="text" class="form-control" id="nomEng_color" name="nomEng_color" value="<?= htmlspecialchars($color['nomEng_color']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="pronunciacion_color" class="form-label">Pronunciación</label>
            <input type="text" class="form-control" id="pronunciacion_color" name="pronunciacion_color" value="<?= htmlspecialchars($color['pronunciacion_color']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="img_color" class="form-label">Foto</label>
            <input type="file" class="form-control" id="img_color" name="img_color">
            <?php if (!empty($color['img_color'])) : ?>
                <img src="data:image/png;base64,<?= base64_encode($color['img_color']) ?>" alt="Imagen de color" style="width: 100px; heigth:100px;">
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="audio_color" class="form-label">Audio</label>
            <input type="file" class="form-control" id="audio_color" name="audio_color">
            <?php if (!empty($color['audio_color'])) : ?>
                <audio controls>
                    <source src="data:audio/mp3;base64,<?= base64_encode($color['audio_color']) ?>" type="audio/mp3">
                </audio>
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-primary" name="btnregistrar" value="ok">Registrar</button>
    </form>
</body>

</html>