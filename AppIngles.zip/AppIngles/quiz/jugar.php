<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit;
}

include("admin/funciones.php");

$confi = obtenerConfiguracion();
$totalPreguntasPorJuego = $confi['totalPreguntas'];

if (isset($_POST['siguiente'])) {
    aumentarRespondidas();

    if ($_SESSION['respuesta_correcta'] == $_POST['respuesta']) {
        $_SESSION['correctas']++;
    }

    $_SESSION['numPreguntaActual']++;
    if ($_SESSION['numPreguntaActual'] < $totalPreguntasPorJuego) {
        $preguntaActualId = $_SESSION['idPreguntas'][$_SESSION['numPreguntaActual']];
        if ($preguntaActualId) {
            $preguntaActual = obtenerPreguntaPorId($preguntaActualId);
            $_SESSION['respuesta_correcta'] = $preguntaActual['correcta'];
        } else {
            die("No se encontró el ID de la pregunta en la sesión.");
        }
    } else {
        $_SESSION['incorrectas'] = $totalPreguntasPorJuego - $_SESSION['correctas'];
        $_SESSION['nombreCategoria'] = obtenerNombreTema($_SESSION['idCategoria']);
        $_SESSION['score'] = ($_SESSION['correctas'] * 100) / $totalPreguntasPorJuego;
        header("Location: final.php");
        exit;
    }
} else {
    $_SESSION['correctas'] = 0;
    $_SESSION['numPreguntaActual'] = 0;
    $_SESSION['preguntas'] = obtenerIdsPreguntasPorCategoria($_SESSION['idCategoria']);

    $_SESSION['idPreguntas'] = [];
    while ($row = mysqli_fetch_assoc($_SESSION['preguntas'])) {
        $_SESSION['idPreguntas'][] = $row['id'];
    }

    shuffle($_SESSION['idPreguntas']);
    $preguntaActualId = $_SESSION['idPreguntas'][0];
    if ($preguntaActualId) {
        $preguntaActual = obtenerPreguntaPorId($preguntaActualId);
        $_SESSION['respuesta_correcta'] = $preguntaActual['correcta'];
    } else {
        die("No se encontró el ID de la primera pregunta.");
    }
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QUIZ GAME</title>
    <link rel="stylesheet" href="estilo.css">
</head>

<body>
    <div class="container-juego" id="container-juego">
        <header class="header">
            <div class="categoria">
                <?php echo obtenerNombreTema($preguntaActual['tema']) ?>
            </div>
            <a href="index.php">Quizgame.com</a>
        </header>
        <div class="info">
            <div class="estadoPregunta">
                Pregunta <span class="numPregunta"><?php echo $_SESSION['numPreguntaActual'] + 1 ?></span> de <?php echo $totalPreguntasPorJuego ?>               
            </div>            
            <h3>
                <?php echo $preguntaActual['pregunta'] ?>
            </h3>
            <!-- Mostrar la imagen de la pregunta si existe -->
            <?php if (!empty($preguntaActual['imagen'])) : ?>
                <div class="imagen-pregunta">
                    <img src="data:image/png;base64,<?php echo base64_encode($preguntaActual['imagen']); ?>" alt="ee">
                </div>
            <?php endif; ?>
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
                <div class="opciones">
                    <label for="respuesta1" onclick="seleccionar(this)" class="op1">
                        <p><?php echo $preguntaActual['opcion_a'] ?></p>
                        <input type="radio" name="respuesta" value="A" id="respuesta1" required>
                    </label>
                    <label for="respuesta2" onclick="seleccionar(this)" class="op2">
                        <p><?php echo $preguntaActual['opcion_b'] ?></p>
                        <input type="radio" name="respuesta" value="B" id="respuesta2" required>
                    </label>
                    <label for="respuesta3" onclick="seleccionar(this)" class="op3">
                        <p><?php echo $preguntaActual['opcion_c'] ?></p>
                        <input type="radio" name="respuesta" value="C" id="respuesta3" required>
                    </label>
                </div>                
                <div class="boton">
                    <input type="submit" value="Siguiente" name="siguiente">
                </div>
            </form>
        </div>
    </div>
    <script src="juego.js"></script>
</body>

</html>