<?php
session_start();

// Verificar la sesión del usuario
if (!$_SESSION['usuarioLogeado']) {
    header("Location: login.php");
    exit;
}

include("funciones.php");

// Procesamiento del formulario cuando se guarda la pregunta
if (isset($_POST['guardar'])) {
    // Validar y procesar la subida de la imagen
    if (isset($_FILES['imagen']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
        $imagen_tmp = $_FILES['imagen']['tmp_name'];
        
        // Leer el contenido de la imagen
        $imagen_contenido = file_get_contents($imagen_tmp);
        
        // Procesar el resto de los datos de la pregunta
        $pregunta = htmlspecialchars($_POST['pregunta']);
        $opcion_a = htmlspecialchars($_POST['opcion_a']);
        $opcion_b = htmlspecialchars($_POST['opcion_b']);
        $opcion_c = htmlspecialchars($_POST['opcion_c']);
        $id_tema = $_POST['tema'];
        $correcta = $_POST['correcta'];

        // Insertar en la base de datos
        include("conexion.php");
        
        // Preparar la consulta usando parámetros seguros
        $stmt = $conn->prepare("INSERT INTO preguntas (id, tema, pregunta, opcion_a, opcion_b, opcion_c, correcta, imagen) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("issssss", $id_tema, $pregunta, $opcion_a, $opcion_b, $opcion_c, $correcta, $imagen_contenido);

        if ($stmt->execute()) {
            $mensaje = "La pregunta se insertó correctamente";
        } else {
            $mensaje = "Error al insertar en la BD: " . $stmt->error;
        }
        
        $stmt->close();
    } else {
        $mensaje = "Error al subir la imagen: " . $_FILES['imagen']['error'];
    }
}

// Obtener todos los temas de la BD
$resultado_temas = obetenerTodosLosTemas();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="estilo.css">
    <title>Quiz Game</title>
</head>
<body>
    <div class="contenedor">
        <header>
            <h1>QUIZ GAME</h1>
        </header>
        <div class="contenedor-info">
            <?php include("nav.php") ?>
            <div class="panel">
                <h2>Complete la Pregunta</h2>
                <hr>
                <section id="nuevaPregunta">
                    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
                        <div class="fila">
                            <label for="tema">Tema:</label>
                            <select name="tema" id="tema">
                                <?php while ($row = mysqli_fetch_assoc($resultado_temas)) : ?>
                                    <option value="<?php echo $row['id'] ?>">
                                        <?php echo $row['nombre'] ?>
                                    </option>
                                <?php endwhile ?>
                            </select>
                            <span class="agregarTema" onclick="agregarTema()">
                                <i class="fa-solid fa-circle-plus"></i> Agregar Tema
                            </span>
                        </div>
                        <div class="fila">
                            <label for="pregunta">Pregunta:</label>
                            <textarea name="pregunta" id="pregunta" cols="30" rows="10" required></textarea>
                        </div>
                        <div class="fila">
                            <label for="imagen">Imagen:</label>
                            <input type="file" name="imagen" id="imagen">
                        </div>
                        <div class="opciones">
                            <div class="opcion">
                                <label for="opcion_a">Opción A</label>
                                <input type="text" name="opcion_a" id="opcion_a" required>
                            </div>
                            <div class="opcion">
                                <label for="opcion_b">Opción B</label>
                                <input type="text" name="opcion_b" id="opcion_b" required>
                            </div>
                            <div class="opcion">
                                <label for="opcion_c">Opción C</label>
                                <input type="text" name="opcion_c" id="opcion_c" required>
                            </div>
                        </div>
                        <div class="opcion">
                            <label for="correcta">Correcta:</label>
                            <select name="correcta" id="correcta" class="correcta">
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                            </select>
                        </div>
                        <hr>
                        <input type="submit" value="Guardar Pregunta" name="guardar" class="btn-guardar">
                    </form>

                    <?php if (isset($mensaje)) : ?>
                        <span> <?php echo $mensaje ?></span>
                    <?php endif ?>
                </section>
            </div>
        </div>
    </div>

    <!-- Ventana Modal para nuevo Tema -->
    <div id="modalTema" class="modal">
        <div class="modal-content">
            <span class="close" onclick="cerrarTema()">&times;</span>
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="get">
                <label for="nombreTema">Agregar Nuevo Tema</label>
                <input type="text" name="nombreTema" id="nombreTema" required>
                <input type="submit" name="nuevoTema" value="Guardar Tema" class="btn">
            </form>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
        paginaActiva(1);
    </script>
</body>
</html>
