<?php

include("conexion.php");
session_start();
// Obtener todas las preguntas de la BD
$query = "SELECT * FROM preguntas";
$resultado = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo.css">
    <title>Listado de Preguntas</title>
</head>
<body>
    <div class="contenedor">
        <header>
            <h1>Listado de Preguntas</h1>
        </header>
        <div class="contenedor-info">
            <?php include("nav.php") ?>
            <div class="panel">
                <h2>Preguntas Guardadas</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tema</th>
                            <th>Pregunta</th>
                            <th>Opción A</th>
                            <th>Opción B</th>
                            <th>Opción C</th>
                            <th>Respuesta Correcta</th>
                            <th>Imagen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($resultado)) : ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo obtenerNombreTema($row['tema']); ?></td>
                                <td><?php echo $row['pregunta']; ?></td>
                                <td><?php echo $row['opcion_a']; ?></td>
                                <td><?php echo $row['opcion_b']; ?></td>
                                <td><?php echo $row['opcion_c']; ?></td>
                                <td><?php echo $row['correcta']; ?></td>
                                <td><img src="mostrar_imagen.php?id=<?php echo $row['id']; ?>" alt="Imagen de la pregunta"></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>