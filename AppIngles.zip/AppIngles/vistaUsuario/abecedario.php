<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/971fd9b73b.js" crossorigin="anonymous"></script>
    <title>Abecedarios</title>
    <link rel="stylesheet" href="prueba.css">
</head>
<body>
    <h1>Abecedarios</h1>
    <div class="container">
        <?php
        include "../modelo/conexion.php";
        $listPer = $conexion->query("SELECT * FROM Abecedarios");
        while ($perFila = $listPer->fetch(PDO::FETCH_ASSOC)) {
            ?>
            <div class="card">
                     <button class="audio-button" data-sound="data:audio/mp3;base64,<?php echo base64_encode($perFila['audio_abecedario']); ?>">
                     <img src="data:image/png;base64,<?php echo base64_encode($perFila['img_abecedario']); ?>" 
                     alt="Imagen del abecedario">
                </button>
                <audio>
                    <source src="data:audio/mp3;base64,<?php echo base64_encode($perFila['audio_abecedario']); ?>" type="audio/mp3">
                </audio>
                <div class="intro">
                    <h1><?php echo $perFila['nomEsp_abecedario']; ?></h1>
                    <?php echo $perFila['pronunciacion_abecedario']; ?></p>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
    <script src="app.js"></script>
</body>
</html>