<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="panel.css">
</head>
<body>
    <div class="container">
        <div class="slide">
            <div class="item" style="background-image: url('/img/Panel-animal.jpg');">
                <div class="content">
                    <div class="name">ANIMALES</div>
                    <div class="des">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ab, eum!</div>
                    <button>
                        <a href="animales.php">Ver animales</a>
                    </button>
                </div>
            </div>
            <div class="item" style="background-image: url('/img/Panel-abecedario.jpg');">
                <div class="content">
                    <div class="name">ABECEDARIO</div>
                    <div class="des">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ab, eum!</div>
                    <button>
                        <a href="abecedario.php">Ver abecedario</a>
                    </button>
                </div>
            </div>
            <div class="item" style="background-image: url('/img/Panel-numero.jpg');">
                <div class="content">
                    <div class="name">NUMEROS</div>
                    <div class="des">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ab, eum!</div>
                    <button>
                        <a href="numero.php">Ver numero</a>
                    </button>
                </div>
            </div>
            <div class="item" style="background-image: url('/img/Panel-fruta.jpg');">
                <div class="content">
                    <div class="name">FRUTAS</div>
                    <div class="des">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ab, eum!</div>
                    <button>
                        <a href="frutas.php">Ver frutas</a>
                    </button>
                </div>
            </div>
            <div class="item" style="background-image: url('/img/Panel-color.jpg');">
                <div class="content">
                    <div class="name">COLORES</div>
                    <div class="des">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ab, eum!</div>
                    <button>
                        <a href="color.php">Ver colores</a>
                    </button>
                </div>
            </div>
            <div class="item" style="background-image: url('/img/Panel-vocal.png');">
                <div class="content">
                    <div class="name">VOCALES</div>
                    <div class="des">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ab, eum!</div>
                    <button>
                        <a href="vocal.php">Ver vocal</a>
                    </button>
                </div>
            </div>
            <div class="item" style="background-image: url('/img/Panel-vegetal.jpg');">
                <div class="content">
                    <div class="name">VEGETALES</div>
                    <div class="des">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ab, eum!</div>
                    <button>
                        <a href="vegetales.php">Ver vegetal</a>
                    </button>
                </div>
            </div>
            <div class="item" style="background-image: url('/img/Panel-salir.jpg');">
                <div class="content">
                    <div class="name">SALIR</div>
                    <div class="des">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ab, eum!</div>
                    <button>
                        <a href="vocal.php">Salir</a>
                    </button>
                </div>
            </div>
            <div class="item" style="background-image: url('/img/juegos.png');">
                <div class="content">
                    <div class="name">Jugar</div>
                    <div class="des">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ab, eum!</div>
                    <button>
                        <a href="/quiz/index.php">Jugar</a>
                    </button>
                </div>
            </div>
        </div>
        <div class="button">
            <button class="prev"><i class="fa-solid fa-arrow-left"></i></button>
            <button class="next"><i class="fa-solid fa-arrow-right"></i></button>
        </div>

    </div>

    <script src="panel.js"></script>
</body>

</html>