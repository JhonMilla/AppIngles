<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/971fd9b73b.js" crossorigin="anonymous"></script>
    <title>Numeros</title>
    <link rel="stylesheet" href="prueba.css">
</head>

<body>
    <h1>Numeros</h1>
    <div class="container">
        <?php
        include "../modelo/conexion.php";
        $listPer = $conexion->query("SELECT * FROM numeros");
        while ($perFila = $listPer->fetch(PDO::FETCH_ASSOC)) {
        ?>
            <div class="card">
                <button class="audio-button" data-sound="data:audio/mp3;base64,<?php echo base64_encode($perFila['audio_numero']); ?>">
                    <img src="data:image/png;base64,<?php echo base64_encode($perFila['img_numero']); ?>" alt="Imagen del numero">
                </button>
                <audio>
                    <source src="data:audio/mp3;base64,<?php echo base64_encode($perFila['audio_numero']); ?>" type="audio/mp3">
                </audio>
                <div class="intro">
                    <h1><?php echo $perFila['nomEsp_numero']; ?></h1>
                    <p><span><?php echo $perFila['nomEng_numero']; ?></span>
                        <?php echo $perFila['pronunciacion_numero']; ?></p>
                </div>
            </div>
        <?php
        }
        ?>
    </div>
    <script src="app.js"></script>
</body>

</html>