document.addEventListener("DOMContentLoaded", function () {
  const audioButtons = document.querySelectorAll(".audio-button");

  audioButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const audio = button.nextElementSibling;
      audio.play().catch((error) => {
        console.error("Error al reproducir el sonido:", error);
      });
    });
  });
});
