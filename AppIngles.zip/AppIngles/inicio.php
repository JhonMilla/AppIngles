<html lang="es">

<head>
    <title>LOGIN</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="wrap">
        <div class="wrap-texto">
            <img src="img/colegio.png" width="100px" height="100px">
            <h1>BIENVENIDO AL COLEGIO ABRAHAM VALDELOMAR 4018</h1>
            <h1>Ingresa a tu perfil</h1>
            <a href="login_profesor.php" class="circular-button">
                <img src="/img/profesor.png" alt="Imagen de profesor">
            </a>
            <a href="login_alumno.php" class="circular-button">
                <img src="/img/alumno.png" alt="Imagen de alumno">
            </a>
        </div>
    </div>
</body>

</html>