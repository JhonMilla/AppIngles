<?php
if (isset($_POST['btnregistrar'])) {
    include "../modelo/conexion.php";  

    $id_abecedario = $_POST['id_abecedario'];
    $nomEsp_abecedario = $_POST['nomEsp_abecedario'];
    $pronunciacion_abecedario = $_POST['pronunciacion_abecedario'];

    // Verificar si se cargaron los archivos
    if ($_FILES['img_abecedario']['error'] === UPLOAD_ERR_OK && $_FILES['audio_abecedario']['error'] === UPLOAD_ERR_OK) {
        $cargar_img_abecedario = $_FILES['img_abecedario']['tmp_name'];
        $cargar_audio_abecedario = $_FILES['audio_abecedario']['tmp_name'];

        // Asegurarse de que los archivos existen y no están vacíos
        if (is_uploaded_file($cargar_img_abecedario) && is_uploaded_file($cargar_audio_abecedario)) {
            $img_abecedario = fopen($cargar_img_abecedario, 'rb');
            $audio_abecedario = fopen($cargar_audio_abecedario, 'rb');

            try {
                $conexion->beginTransaction();
                $modificarAni = $conexion->prepare("UPDATE abecedarios SET img_abecedario=:img_abecedario, nomEsp_abecedario=:nomEsp_abecedario, audio_abecedario=:audio_abecedario, pronunciacion_abecedario=:pronunciacion_abecedario WHERE id_abecedario=:id_abecedario");

                $modificarAni->bindParam(':id_abecedario', $id_abecedario, PDO::PARAM_INT);
                $modificarAni->bindParam(':img_abecedario', $img_abecedario, PDO::PARAM_LOB);
                $modificarAni->bindParam(':nomEsp_abecedario', $nomEsp_abecedario, PDO::PARAM_STR);
                $modificarAni->bindParam(':audio_abecedario', $audio_abecedario, PDO::PARAM_LOB);
                $modificarAni->bindParam(':pronunciacion_abecedario', $pronunciacion_abecedario, PDO::PARAM_STR);

                $modificarAni->execute();
                $conexion->commit();

                echo '<div class="alert alert-success">abecedario modificado correctamente</div>';
                echo '<script>window.location.href="../abecedario.php";</script>'; // Redirigir a index.php
            } catch (Exception $e) {
                $conexion->rollBack();
                echo '<div class="alert alert-danger">Error al modificar: ' . $e->getMessage() . '</div>';
            } finally {
                fclose($img_abecedario);
                fclose($audio_abecedario);
            }
        } else {
            echo '<div class="alert alert-danger">Error al cargar los archivos</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Completar los campos</div>';
    }
}
?>