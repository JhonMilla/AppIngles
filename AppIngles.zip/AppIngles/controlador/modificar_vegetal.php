<?php
if (isset($_POST['btnregistrar'])) {
    include "../modelo/conexion.php";  

    $id_vegetal = $_POST['id_vegetal'];
    $nomEsp_vegetal = $_POST['nomEsp_vegetal'];
    $nomEng_vegetal = $_POST['nomEng_vegetal'];
    $pronunciacion_vegetal = $_POST['pronunciacion_vegetal'];

    // Verificar si se cargaron los archivos
    if ($_FILES['img_vegetal']['error'] === UPLOAD_ERR_OK && $_FILES['audio_vegetal']['error'] === UPLOAD_ERR_OK) {
        $cargar_img_vegetal = $_FILES['img_vegetal']['tmp_name'];
        $cargar_audio_vegetal = $_FILES['audio_vegetal']['tmp_name'];

        // Asegurarse de que los archivos existen y no están vacíos
        if (is_uploaded_file($cargar_img_vegetal) && is_uploaded_file($cargar_audio_vegetal)) {
            $img_vegetal = fopen($cargar_img_vegetal, 'rb');
            $audio_vegetal = fopen($cargar_audio_vegetal, 'rb');

            try {
                $conexion->beginTransaction();
                $modificarAni = $conexion->prepare("UPDATE vegetales SET img_vegetal=:img_vegetal, nomEsp_vegetal=:nomEsp_vegetal, nomEng_vegetal=:nomEng_vegetal, audio_vegetal=:audio_vegetal, pronunciacion_vegetal=:pronunciacion_vegetal WHERE id_vegetal=:id_vegetal");

                $modificarAni->bindParam(':id_vegetal', $id_vegetal, PDO::PARAM_INT);
                $modificarAni->bindParam(':img_vegetal', $img_vegetal, PDO::PARAM_LOB);
                $modificarAni->bindParam(':nomEsp_vegetal', $nomEsp_vegetal, PDO::PARAM_STR);
                $modificarAni->bindParam(':nomEng_vegetal', $nomEng_vegetal, PDO::PARAM_STR);
                $modificarAni->bindParam(':audio_vegetal', $audio_vegetal, PDO::PARAM_LOB);
                $modificarAni->bindParam(':pronunciacion_vegetal', $pronunciacion_vegetal, PDO::PARAM_STR);

                $modificarAni->execute();
                $conexion->commit();

                echo '<div class="alert alert-success">vegetal modificado correctamente</div>';
                echo '<script>window.location.href="../index.php";</script>'; // Redirigir a index.php
            } catch (Exception $e) {
                $conexion->rollBack();
                echo '<div class="alert alert-danger">Error al modificar: ' . $e->getMessage() . '</div>';
            } finally {
                fclose($img_vegetal);
                fclose($audio_vegetal);
            }
        } else {
            echo '<div class="alert alert-danger">Error al cargar los archivos</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Completar los campos</div>';
    }
}
?>