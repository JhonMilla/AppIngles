<?php
if (isset($_POST['btnregistrar'])) {
    include "../modelo/conexion.php";  

    $id_color = $_POST['id_color'];
    $nomEsp_color = $_POST['nomEsp_color'];
    $nomEng_color = $_POST['nomEng_color'];
    $pronunciacion_color = $_POST['pronunciacion_color'];

    // Verificar si se cargaron los archivos
    if ($_FILES['img_color']['error'] === UPLOAD_ERR_OK && $_FILES['audio_color']['error'] === UPLOAD_ERR_OK) {
        $cargar_img_color = $_FILES['img_color']['tmp_name'];
        $cargar_audio_color = $_FILES['audio_color']['tmp_name'];

        // Asegurarse de que los archivos existen y no están vacíos
        if (is_uploaded_file($cargar_img_color) && is_uploaded_file($cargar_audio_color)) {
            $img_color = fopen($cargar_img_color, 'rb');
            $audio_color = fopen($cargar_audio_color, 'rb');

            try {
                $conexion->beginTransaction();
                $modificarAni = $conexion->prepare("UPDATE colores SET img_color=:img_color, nomEsp_color=:nomEsp_color, nomEng_color=:nomEng_color, audio_color=:audio_color, pronunciacion_color=:pronunciacion_color WHERE id_color=:id_color");

                $modificarAni->bindParam(':id_color', $id_color, PDO::PARAM_INT);
                $modificarAni->bindParam(':img_color', $img_color, PDO::PARAM_LOB);
                $modificarAni->bindParam(':nomEsp_color', $nomEsp_color, PDO::PARAM_STR);
                $modificarAni->bindParam(':nomEng_color', $nomEng_color, PDO::PARAM_STR);
                $modificarAni->bindParam(':audio_color', $audio_color, PDO::PARAM_LOB);
                $modificarAni->bindParam(':pronunciacion_color', $pronunciacion_color, PDO::PARAM_STR);

                $modificarAni->execute();
                $conexion->commit();

                echo '<div class="alert alert-success">color modificado correctamente</div>';
                echo '<script>window.location.href="../color.php";</script>'; // Redirigir a index.php
            } catch (Exception $e) {
                $conexion->rollBack();
                echo '<div class="alert alert-danger">Error al modificar: ' . $e->getMessage() . '</div>';
            } finally {
                fclose($img_color);
                fclose($audio_color);
            }
        } else {
            echo '<div class="alert alert-danger">Error al cargar los archivos</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Completar los campos</div>';
    }
}
?>