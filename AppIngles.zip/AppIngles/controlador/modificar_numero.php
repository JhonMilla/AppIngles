<?php
if (isset($_POST['btnregistrar'])) {
    include "../modelo/conexion.php";  

    $id_numero = $_POST['id_numero'];
    $nomEsp_numero = $_POST['nomEsp_numero'];
    $nomEng_numero = $_POST['nomEng_numero'];
    $pronunciacion_numero = $_POST['pronunciacion_numero'];

    // Verificar si se cargaron los archivos
    if ($_FILES['img_numero']['error'] === UPLOAD_ERR_OK && $_FILES['audio_numero']['error'] === UPLOAD_ERR_OK) {
        $cargar_img_numero = $_FILES['img_numero']['tmp_name'];
        $cargar_audio_numero = $_FILES['audio_numero']['tmp_name'];

        // Asegurarse de que los archivos existen y no están vacíos
        if (is_uploaded_file($cargar_img_numero) && is_uploaded_file($cargar_audio_numero)) {
            $img_numero = fopen($cargar_img_numero, 'rb');
            $audio_numero = fopen($cargar_audio_numero, 'rb');

            try {
                $conexion->beginTransaction();
                $modificarAni = $conexion->prepare("UPDATE numeros SET img_numero=:img_numero, nomEsp_numero=:nomEsp_numero, nomEng_numero=:nomEng_numero, audio_numero=:audio_numero, pronunciacion_numero=:pronunciacion_numero WHERE id_numero=:id_numero");

                $modificarAni->bindParam(':id_numero', $id_numero, PDO::PARAM_INT);
                $modificarAni->bindParam(':img_numero', $img_numero, PDO::PARAM_LOB);
                $modificarAni->bindParam(':nomEsp_numero', $nomEsp_numero, PDO::PARAM_STR);
                $modificarAni->bindParam(':nomEng_numero', $nomEng_numero, PDO::PARAM_STR);
                $modificarAni->bindParam(':audio_numero', $audio_numero, PDO::PARAM_LOB);
                $modificarAni->bindParam(':pronunciacion_numero', $pronunciacion_numero, PDO::PARAM_STR);

                $modificarAni->execute();
                $conexion->commit();

                echo '<div class="alert alert-success">numero modificado correctamente</div>';
                echo '<script>window.location.href="../numero.php";</script>'; // Redirigir a index.php
            } catch (Exception $e) {
                $conexion->rollBack();
                echo '<div class="alert alert-danger">Error al modificar: ' . $e->getMessage() . '</div>';
            } finally {
                fclose($img_numero);
                fclose($audio_numero);
            }
        } else {
            echo '<div class="alert alert-danger">Error al cargar los archivos</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Completar los campos</div>';
    }
}
?>