<?php
// Incluir el archivo de conexión a la base de datos
include "../modelo/conexion.php";

// Verificar si se recibió una solicitud de eliminación
if (isset($_POST['btneliminar'])) {
    // Obtener el ID del registro a eliminar
    $id_color = $_POST['id_color'];

    try {
        // Preparar la consulta de eliminación
        $stmt = $conexion->prepare("DELETE FROM colores WHERE id_color = :id_color");
        $stmt->bindParam(':id_color', $id_color, PDO::PARAM_INT);

        // Ejecutar la consulta
        $stmt->execute();

        // Verificar si se eliminó el registro correctamente
        if ($stmt->rowCount() > 0) {
            echo '<div class="alert alert-success">color eliminado correctamente</div>';
            header("Location: " . $_SERVER['HTTP_REFERER']);
            exit();
        } else {
            echo '<div class="alert alert-warning">No se encontró el color a eliminar</div>';
        }
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">Error al eliminar el color: ' . $e->getMessage() . '</div>';
    }
}
?>