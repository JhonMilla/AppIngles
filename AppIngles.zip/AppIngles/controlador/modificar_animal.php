<?php
if (isset($_POST['btnregistrar'])) {
    include "../modelo/conexion.php";  

    $id_animal = $_POST['id_animal'];
    $nomEsp_animal = $_POST['nomEsp_animal'];
    $nomEng_animal = $_POST['nomEng_animal'];
    $pronunciacion_animal = $_POST['pronunciacion_animal'];

    // Verificar si se cargaron los archivos
    if ($_FILES['img_animal']['error'] === UPLOAD_ERR_OK && $_FILES['audio_animal']['error'] === UPLOAD_ERR_OK) {
        $cargar_img_animal = $_FILES['img_animal']['tmp_name'];
        $cargar_audio_animal = $_FILES['audio_animal']['tmp_name'];

        // Asegurarse de que los archivos existen y no están vacíos
        if (is_uploaded_file($cargar_img_animal) && is_uploaded_file($cargar_audio_animal)) {
            $img_animal = fopen($cargar_img_animal, 'rb');
            $audio_animal = fopen($cargar_audio_animal, 'rb');

            try {
                $conexion->beginTransaction();
                $modificarAni = $conexion->prepare("UPDATE animales SET img_animal=:img_animal, nomEsp_animal=:nomEsp_animal, nomEng_animal=:nomEng_animal, audio_animal=:audio_animal, pronunciacion_animal=:pronunciacion_animal WHERE id_animal=:id_animal");

                $modificarAni->bindParam(':id_animal', $id_animal, PDO::PARAM_INT);
                $modificarAni->bindParam(':img_animal', $img_animal, PDO::PARAM_LOB);
                $modificarAni->bindParam(':nomEsp_animal', $nomEsp_animal, PDO::PARAM_STR);
                $modificarAni->bindParam(':nomEng_animal', $nomEng_animal, PDO::PARAM_STR);
                $modificarAni->bindParam(':audio_animal', $audio_animal, PDO::PARAM_LOB);
                $modificarAni->bindParam(':pronunciacion_animal', $pronunciacion_animal, PDO::PARAM_STR);

                $modificarAni->execute();
                $conexion->commit();

                echo '<div class="alert alert-success">Animal modificado correctamente</div>';
                echo '<script>window.location.href="../index.php";</script>'; // Redirigir a index.php
            } catch (Exception $e) {
                $conexion->rollBack();
                echo '<div class="alert alert-danger">Error al modificar: ' . $e->getMessage() . '</div>';
            } finally {
                fclose($img_animal);
                fclose($audio_animal);
            }
        } else {
            echo '<div class="alert alert-danger">Error al cargar los archivos</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Completar los campos</div>';
    }
}
?>