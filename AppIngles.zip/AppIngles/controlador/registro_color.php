<?php
if (isset($_POST['btnregistrar'])) {
    include "./modelo/conexion.php";  

    $nomEsp_color = $_POST['nomEsp_color'];
    $nomEng_color = $_POST['nomEng_color'];
    $pronunciacion_color = $_POST['pronunciacion_color'];

    // Verificar si se cargaron los archivos
    if ($_FILES['img_color']['error'] === UPLOAD_ERR_OK && $_FILES['audio_color']['error'] === UPLOAD_ERR_OK) {
        $cargar_img_color = $_FILES['img_color']['tmp_name'];
        $cargar_audio_color = $_FILES['audio_color']['tmp_name'];

        // Asegurarse de que los archivos existen y no están vacíos
        if (is_uploaded_file($cargar_img_color) && is_uploaded_file($cargar_audio_color)) {
            $img_color = fopen($cargar_img_color, 'rb');
            $audio_color = fopen($cargar_audio_color, 'rb');

            try {
                $conexion->beginTransaction();
                $insertarAni = $conexion->prepare("INSERT INTO colores (img_color, nomEsp_color, nomEng_color, audio_color, pronunciacion_color) VALUES (:img_color, :nomEsp_color, :nomEng_color, :audio_color, :pronunciacion_color)");

                $insertarAni->bindParam(':img_color', $img_color, PDO::PARAM_LOB);
                $insertarAni->bindParam(':nomEsp_color', $nomEsp_color, PDO::PARAM_STR);
                $insertarAni->bindParam(':nomEng_color', $nomEng_color, PDO::PARAM_STR);
                $insertarAni->bindParam(':audio_color', $audio_color, PDO::PARAM_LOB);
                $insertarAni->bindParam(':pronunciacion_color', $pronunciacion_color, PDO::PARAM_STR);

                $insertarAni->execute();
                $conexion->commit();

                echo '<div class="alert alert-success">colores registrado correctamente</div>';
            } catch (Exception $e) {
                $conexion->rollBack();
                echo '<div class="alert alert-danger">Error al registrar: ' . $e->getMessage() . '</div>';
            } finally {
                fclose($img_color);
                fclose($audio_color);
            }
        } else {
            echo '<div class="alert alert-danger">Error al cargar los archivos</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Completar los campos</div>';
    }
}
?>