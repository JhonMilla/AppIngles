<?php
if (isset($_POST['btnregistrar'])) {
    include "../modelo/conexion.php";  

    $id_vocal = $_POST['id_vocal'];
    $nomEsp_vocal = $_POST['nomEsp_vocal'];
    $pronunciacion_vocal = $_POST['pronunciacion_vocal'];

    // Verificar si se cargaron los archivos
    if ($_FILES['img_vocal']['error'] === UPLOAD_ERR_OK && $_FILES['audio_vocal']['error'] === UPLOAD_ERR_OK) {
        $cargar_img_vocal = $_FILES['img_vocal']['tmp_name'];
        $cargar_audio_vocal = $_FILES['audio_vocal']['tmp_name'];

        // Asegurarse de que los archivos existen y no están vacíos
        if (is_uploaded_file($cargar_img_vocal) && is_uploaded_file($cargar_audio_vocal)) {
            $img_vocal = fopen($cargar_img_vocal, 'rb');
            $audio_vocal = fopen($cargar_audio_vocal, 'rb');

            try {
                $conexion->beginTransaction();
                $modificarAni = $conexion->prepare("UPDATE vocales SET img_vocal=:img_vocal, nomEsp_vocal=:nomEsp_vocal, audio_vocal=:audio_vocal, pronunciacion_vocal=:pronunciacion_vocal WHERE id_vocal=:id_vocal");

                $modificarAni->bindParam(':id_vocal', $id_vocal, PDO::PARAM_INT);
                $modificarAni->bindParam(':img_vocal', $img_vocal, PDO::PARAM_LOB);
                $modificarAni->bindParam(':nomEsp_vocal', $nomEsp_vocal, PDO::PARAM_STR);
                $modificarAni->bindParam(':audio_vocal', $audio_vocal, PDO::PARAM_LOB);
                $modificarAni->bindParam(':pronunciacion_vocal', $pronunciacion_vocal, PDO::PARAM_STR);

                $modificarAni->execute();
                $conexion->commit();

                echo '<div class="alert alert-success">vocal modificado correctamente</div>';
                echo '<script>window.location.href="../vocal.php";</script>'; // Redirigir a index.php
            } catch (Exception $e) {
                $conexion->rollBack();
                echo '<div class="alert alert-danger">Error al modificar: ' . $e->getMessage() . '</div>';
            } finally {
                fclose($img_vocal);
                fclose($audio_vocal);
            }
        } else {
            echo '<div class="alert alert-danger">Error al cargar los archivos</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Completar los campos</div>';
    }
}
?>