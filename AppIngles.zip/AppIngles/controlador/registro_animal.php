<?php
if (isset($_POST['btnregistrar'])) {
    include "./modelo/conexion.php";  

    $nomEsp_animal = $_POST['nomEsp_animal'];
    $nomEng_animal = $_POST['nomEng_animal'];
    $pronunciacion_animal = $_POST['pronunciacion_animal'];

    // Verificar si se cargaron los archivos
    if ($_FILES['img_animal']['error'] === UPLOAD_ERR_OK && $_FILES['audio_animal']['error'] === UPLOAD_ERR_OK) {
        $cargar_img_animal = $_FILES['img_animal']['tmp_name'];
        $cargar_audio_animal = $_FILES['audio_animal']['tmp_name'];

        // Asegurarse de que los archivos existen y no están vacíos
        if (is_uploaded_file($cargar_img_animal) && is_uploaded_file($cargar_audio_animal)) {
            $img_animal = fopen($cargar_img_animal, 'rb');
            $audio_animal = fopen($cargar_audio_animal, 'rb');

            try {
                $conexion->beginTransaction();
                $insertarAni = $conexion->prepare("INSERT INTO animales (img_animal, nomEsp_animal, nomEng_animal, audio_animal, pronunciacion_animal) VALUES (:img_animal, :nomEsp_animal, :nomEng_animal, :audio_animal, :pronunciacion_animal)");

                $insertarAni->bindParam(':img_animal', $img_animal, PDO::PARAM_LOB);
                $insertarAni->bindParam(':nomEsp_animal', $nomEsp_animal, PDO::PARAM_STR);
                $insertarAni->bindParam(':nomEng_animal', $nomEng_animal, PDO::PARAM_STR);
                $insertarAni->bindParam(':audio_animal', $audio_animal, PDO::PARAM_LOB);
                $insertarAni->bindParam(':pronunciacion_animal', $pronunciacion_animal, PDO::PARAM_STR);

                $insertarAni->execute();
                $conexion->commit();

                echo '<div class="alert alert-success">Animal registrado correctamente</div>';
            } catch (Exception $e) {
                $conexion->rollBack();
                echo '<div class="alert alert-danger">Error al registrar: ' . $e->getMessage() . '</div>';
            } finally {
                fclose($img_animal);
                fclose($audio_animal);
            }
        } else {
            echo '<div class="alert alert-danger">Error al cargar los archivos</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Completar los campos</div>';
    }
}
?>