<?php
// Incluir el archivo de conexión a la base de datos
include "../modelo/conexion.php";

// Verificar si se recibió una solicitud de eliminación
if (isset($_POST['btneliminar'])) {
    // Obtener el ID del registro a eliminar
    $id_animal = $_POST['id_animal'];

    try {
        // Preparar la consulta de eliminación
        $stmt = $conexion->prepare("DELETE FROM animales WHERE id_animal = :id_animal");
        $stmt->bindParam(':id_animal', $id_animal, PDO::PARAM_INT);

        // Ejecutar la consulta
        $stmt->execute();

        // Verificar si se eliminó el registro correctamente
        if ($stmt->rowCount() > 0) {
            echo '<div class="alert alert-success">Animal eliminado correctamente</div>';
            header("Location: " . $_SERVER['HTTP_REFERER']);
            exit();
        } else {
            echo '<div class="alert alert-warning">No se encontró el animal a eliminar</div>';
        }
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">Error al eliminar el animal: ' . $e->getMessage() . '</div>';
    }
}
?>