<?php
// Incluir el archivo de conexión a la base de datos
include "../modelo/conexion.php";

// Verificar si se recibió una solicitud de eliminación
if (isset($_POST['btneliminar'])) {
    // Obtener el ID del registro a eliminar
    $id_vocal = $_POST['id_vocal'];

    try {
        // Preparar la consulta de eliminación
        $stmt = $conexion->prepare("DELETE FROM vocales WHERE id_vocal = :id_vocal");
        $stmt->bindParam(':id_vocal', $id_vocal, PDO::PARAM_INT);

        // Ejecutar la consulta
        $stmt->execute();

        // Verificar si se eliminó el registro correctamente
        if ($stmt->rowCount() > 0) {
            echo '<div class="alert alert-success">vocal eliminado correctamente</div>';
            header("Location: " . $_SERVER['HTTP_REFERER']);
            exit();
        } else {
            echo '<div class="alert alert-warning">No se encontró el vocal a eliminar</div>';
        }
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">Error al eliminar el vocal: ' . $e->getMessage() . '</div>';
    }
}
?>