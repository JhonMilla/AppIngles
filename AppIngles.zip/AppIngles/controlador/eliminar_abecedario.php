<?php
// Incluir el archivo de conexión a la base de datos
include "../modelo/conexion.php";

// Verificar si se recibió una solicitud de eliminación
if (isset($_POST['btneliminar'])) {
    // Obtener el ID del registro a eliminar
    $id_abecedario = $_POST['id_abecedario'];

    try {
        // Preparar la consulta de eliminación
        $stmt = $conexion->prepare("DELETE FROM abecedarios WHERE id_abecedario = :id_abecedario");
        $stmt->bindParam(':id_abecedario', $id_abecedario, PDO::PARAM_INT);

        // Ejecutar la consulta
        $stmt->execute();

        // Verificar si se eliminó el registro correctamente
        if ($stmt->rowCount() > 0) {
            echo '<div class="alert alert-success">abecedario eliminado correctamente</div>';
            header("Location: " . $_SERVER['HTTP_REFERER']);
            exit();
        } else {
            echo '<div class="alert alert-warning">No se encontró el abecedario a eliminar</div>';
        }
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">Error al eliminar el abecedario: ' . $e->getMessage() . '</div>';
    }
}
?>