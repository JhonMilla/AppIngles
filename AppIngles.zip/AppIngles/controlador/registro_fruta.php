<?php
if (isset($_POST['btnregistrar'])) {
    include "./modelo/conexion.php";  

    $nomEsp_fruta = $_POST['nomEsp_fruta'];
    $nomEng_fruta = $_POST['nomEng_fruta'];
    $pronunciacion_fruta = $_POST['pronunciacion_fruta'];

    // Verificar si se cargaron los archivos
    if ($_FILES['img_fruta']['error'] === UPLOAD_ERR_OK && $_FILES['audio_fruta']['error'] === UPLOAD_ERR_OK) {
        $cargar_img_fruta = $_FILES['img_fruta']['tmp_name'];
        $cargar_audio_fruta = $_FILES['audio_fruta']['tmp_name'];

        // Asegurarse de que los archivos existen y no están vacíos
        if (is_uploaded_file($cargar_img_fruta) && is_uploaded_file($cargar_audio_fruta)) {
            $img_fruta = fopen($cargar_img_fruta, 'rb');
            $audio_fruta = fopen($cargar_audio_fruta, 'rb');

            try {
                $conexion->beginTransaction();
                $insertarAni = $conexion->prepare("INSERT INTO frutas (img_fruta, nomEsp_fruta, nomEng_fruta, audio_fruta, pronunciacion_fruta) VALUES (:img_fruta, :nomEsp_fruta, :nomEng_fruta, :audio_fruta, :pronunciacion_fruta)");

                $insertarAni->bindParam(':img_fruta', $img_fruta, PDO::PARAM_LOB);
                $insertarAni->bindParam(':nomEsp_fruta', $nomEsp_fruta, PDO::PARAM_STR);
                $insertarAni->bindParam(':nomEng_fruta', $nomEng_fruta, PDO::PARAM_STR);
                $insertarAni->bindParam(':audio_fruta', $audio_fruta, PDO::PARAM_LOB);
                $insertarAni->bindParam(':pronunciacion_fruta', $pronunciacion_fruta, PDO::PARAM_STR);

                $insertarAni->execute();
                $conexion->commit();

                echo '<div class="alert alert-success">frutas registrado correctamente</div>';
            } catch (Exception $e) {
                $conexion->rollBack();
                echo '<div class="alert alert-danger">Error al registrar: ' . $e->getMessage() . '</div>';
            } finally {
                fclose($img_fruta);
                fclose($audio_fruta);
            }
        } else {
            echo '<div class="alert alert-danger">Error al cargar los archivos</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Completar los campos</div>';
    }
}
?>